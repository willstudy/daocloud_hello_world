#!/bin/bash

python manage.py runserver 0.0.0.0:23333
